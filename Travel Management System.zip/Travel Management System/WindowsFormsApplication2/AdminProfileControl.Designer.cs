﻿namespace WindowsFormsApplication2
{
    partial class AdminProfileControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxPasswordAdmin = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxNameAdmin = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.buttonAddNewAdmin = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBoxPasswordAdmin
            // 
            this.textBoxPasswordAdmin.Location = new System.Drawing.Point(233, 235);
            this.textBoxPasswordAdmin.Name = "textBoxPasswordAdmin";
            this.textBoxPasswordAdmin.Size = new System.Drawing.Size(200, 22);
            this.textBoxPasswordAdmin.TabIndex = 49;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(71, 228);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 29);
            this.label9.TabIndex = 41;
            this.label9.Text = "Password:";
            // 
            // textBoxNameAdmin
            // 
            this.textBoxNameAdmin.Location = new System.Drawing.Point(233, 177);
            this.textBoxNameAdmin.Name = "textBoxNameAdmin";
            this.textBoxNameAdmin.Size = new System.Drawing.Size(200, 22);
            this.textBoxNameAdmin.TabIndex = 39;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(289, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(183, 36);
            this.label6.TabIndex = 36;
            this.label6.Text = "Add Admin";
            // 
            // buttonAddNewAdmin
            // 
            this.buttonAddNewAdmin.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.buttonAddNewAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAddNewAdmin.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAddNewAdmin.ForeColor = System.Drawing.Color.Black;
            this.buttonAddNewAdmin.Location = new System.Drawing.Point(541, 187);
            this.buttonAddNewAdmin.Name = "buttonAddNewAdmin";
            this.buttonAddNewAdmin.Size = new System.Drawing.Size(151, 51);
            this.buttonAddNewAdmin.TabIndex = 35;
            this.buttonAddNewAdmin.Text = "ADD";
            this.buttonAddNewAdmin.UseVisualStyleBackColor = false;
            this.buttonAddNewAdmin.Click += new System.EventHandler(this.buttonAddNewAdmin_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(71, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 29);
            this.label1.TabIndex = 31;
            this.label1.Text = "Name:";
            // 
            // AdminProfileControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Controls.Add(this.textBoxPasswordAdmin);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxNameAdmin);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonAddNewAdmin);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "AdminProfileControl";
            this.Size = new System.Drawing.Size(789, 424);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxPasswordAdmin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxNameAdmin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button buttonAddNewAdmin;
        private System.Windows.Forms.Label label1;
    }
}
