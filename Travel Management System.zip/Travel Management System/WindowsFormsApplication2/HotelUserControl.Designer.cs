﻿namespace WindowsFormsApplication2
{
    partial class HotelUserControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HotelUserControl));
            this.buttonHotel1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonHotel2 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonHotel3 = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.buttonHotel6 = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.buttonHotel5 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.buttonHotel4 = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
//            this.hotelDetailsUserControl1 = new WindowsFormsApplication2.HotelDetailsUserControl();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonHotel1
            // 
            this.buttonHotel1.BackColor = System.Drawing.Color.White;
            this.buttonHotel1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHotel1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonHotel1.Location = new System.Drawing.Point(14, 150);
            this.buttonHotel1.Name = "buttonHotel1";
            this.buttonHotel1.Size = new System.Drawing.Size(201, 35);
            this.buttonHotel1.TabIndex = 6;
            this.buttonHotel1.Text = "SLS Hotel";
            this.buttonHotel1.UseVisualStyleBackColor = false;
            this.buttonHotel1.Click += new System.EventHandler(this.buttonHotel1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(14, 16);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(201, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // buttonHotel2
            // 
            this.buttonHotel2.BackColor = System.Drawing.Color.White;
            this.buttonHotel2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHotel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonHotel2.Location = new System.Drawing.Point(271, 150);
            this.buttonHotel2.Name = "buttonHotel2";
            this.buttonHotel2.Size = new System.Drawing.Size(201, 35);
            this.buttonHotel2.TabIndex = 8;
            this.buttonHotel2.Text = "Royal Mansour";
            this.buttonHotel2.UseVisualStyleBackColor = false;
            this.buttonHotel2.Click += new System.EventHandler(this.buttonHotel2_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(271, 16);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(201, 128);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // buttonHotel3
            // 
            this.buttonHotel3.BackColor = System.Drawing.Color.White;
            this.buttonHotel3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHotel3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonHotel3.Location = new System.Drawing.Point(529, 150);
            this.buttonHotel3.Name = "buttonHotel3";
            this.buttonHotel3.Size = new System.Drawing.Size(201, 35);
            this.buttonHotel3.TabIndex = 10;
            this.buttonHotel3.Text = "Pan Pacific";
            this.buttonHotel3.UseVisualStyleBackColor = false;
            this.buttonHotel3.Click += new System.EventHandler(this.buttonHotel3_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(529, 16);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(201, 128);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 9;
            this.pictureBox3.TabStop = false;
            // 
            // buttonHotel6
            // 
            this.buttonHotel6.BackColor = System.Drawing.Color.White;
            this.buttonHotel6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHotel6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonHotel6.Location = new System.Drawing.Point(529, 325);
            this.buttonHotel6.Name = "buttonHotel6";
            this.buttonHotel6.Size = new System.Drawing.Size(201, 35);
            this.buttonHotel6.TabIndex = 16;
            this.buttonHotel6.Text = "Astoria";
            this.buttonHotel6.UseVisualStyleBackColor = false;
            this.buttonHotel6.Click += new System.EventHandler(this.buttonHotel6_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(529, 191);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(201, 128);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 15;
            this.pictureBox4.TabStop = false;
            // 
            // buttonHotel5
            // 
            this.buttonHotel5.BackColor = System.Drawing.Color.White;
            this.buttonHotel5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHotel5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonHotel5.Location = new System.Drawing.Point(271, 325);
            this.buttonHotel5.Name = "buttonHotel5";
            this.buttonHotel5.Size = new System.Drawing.Size(201, 35);
            this.buttonHotel5.TabIndex = 14;
            this.buttonHotel5.Text = "Rosewood";
            this.buttonHotel5.UseVisualStyleBackColor = false;
            this.buttonHotel5.Click += new System.EventHandler(this.buttonHotel5_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(271, 191);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(201, 128);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 13;
            this.pictureBox5.TabStop = false;
            // 
            // buttonHotel4
            // 
            this.buttonHotel4.BackColor = System.Drawing.Color.White;
            this.buttonHotel4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHotel4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonHotel4.Location = new System.Drawing.Point(14, 325);
            this.buttonHotel4.Name = "buttonHotel4";
            this.buttonHotel4.Size = new System.Drawing.Size(201, 35);
            this.buttonHotel4.TabIndex = 12;
            this.buttonHotel4.Text = "J.W Marriot";
            this.buttonHotel4.UseVisualStyleBackColor = false;
            this.buttonHotel4.Click += new System.EventHandler(this.buttonHotel4_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(14, 191);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(201, 128);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 11;
            this.pictureBox6.TabStop = false;
            // 
            // hotelDetailsUserControl1
            // 
            //this.hotelDetailsUserControl1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            //this.hotelDetailsUserControl1.ForeColor = System.Drawing.Color.White;
            //this.hotelDetailsUserControl1.Location = new System.Drawing.Point(-3, -3);
            //this.hotelDetailsUserControl1.Name = "hotelDetailsUserControl1";
            //this.hotelDetailsUserControl1.Size = new System.Drawing.Size(755, 390);
            //this.hotelDetailsUserControl1.TabIndex = 17;
            // 
            // HotelUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
           // this.Controls.Add(this.hotelDetailsUserControl1);
            this.Controls.Add(this.buttonHotel6);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.buttonHotel5);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.buttonHotel4);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.buttonHotel3);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.buttonHotel2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.buttonHotel1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "HotelUserControl";
            this.Size = new System.Drawing.Size(755, 390);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonHotel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonHotel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button buttonHotel3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button buttonHotel6;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Button buttonHotel5;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Button buttonHotel4;
        private System.Windows.Forms.PictureBox pictureBox6;
       // private HotelDetailsUserControl hotelDetailsUserControl1;
    }
}