﻿namespace WindowsFormsApplication2
{
    partial class HotellUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewShowwwHotels = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxSearchHotell = new System.Windows.Forms.TextBox();
            this.buttonDeleteShowHotel = new System.Windows.Forms.Button();
            this.buttonRetrieveShowHotels = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowwwHotels)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewShowwwHotels
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Silver;
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewShowwwHotels.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewShowwwHotels.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridViewShowwwHotels.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewShowwwHotels.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowwwHotels.GridColor = System.Drawing.Color.Black;
            this.dataGridViewShowwwHotels.Location = new System.Drawing.Point(0, 186);
            this.dataGridViewShowwwHotels.Name = "dataGridViewShowwwHotels";
            this.dataGridViewShowwwHotels.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridViewShowwwHotels.RowHeadersWidth = 51;
            this.dataGridViewShowwwHotels.RowTemplate.Height = 24;
            this.dataGridViewShowwwHotels.Size = new System.Drawing.Size(894, 302);
            this.dataGridViewShowwwHotels.TabIndex = 56;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(267, 276);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 55;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Snap ITC", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(258, 11);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(355, 51);
            this.label3.TabIndex = 54;
            this.label3.Text = "Booked Hotels";
            // 
            // textBoxSearchHotell
            // 
            this.textBoxSearchHotell.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxSearchHotell.Location = new System.Drawing.Point(551, 79);
            this.textBoxSearchHotell.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSearchHotell.Name = "textBoxSearchHotell";
            this.textBoxSearchHotell.Size = new System.Drawing.Size(280, 22);
            this.textBoxSearchHotell.TabIndex = 53;
            // 
            // buttonDeleteShowHotel
            // 
            this.buttonDeleteShowHotel.BackColor = System.Drawing.Color.Black;
            this.buttonDeleteShowHotel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDeleteShowHotel.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonDeleteShowHotel.FlatAppearance.BorderSize = 2;
            this.buttonDeleteShowHotel.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonDeleteShowHotel.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonDeleteShowHotel.Location = new System.Drawing.Point(705, 109);
            this.buttonDeleteShowHotel.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDeleteShowHotel.Name = "buttonDeleteShowHotel";
            this.buttonDeleteShowHotel.Size = new System.Drawing.Size(126, 28);
            this.buttonDeleteShowHotel.TabIndex = 52;
            this.buttonDeleteShowHotel.Text = "Delete Booking";
            this.buttonDeleteShowHotel.UseVisualStyleBackColor = false;
            this.buttonDeleteShowHotel.Click += new System.EventHandler(this.buttonDeleteShowHotel_Click);
            // 
            // buttonRetrieveShowHotels
            // 
            this.buttonRetrieveShowHotels.BackColor = System.Drawing.Color.Black;
            this.buttonRetrieveShowHotels.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonRetrieveShowHotels.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonRetrieveShowHotels.FlatAppearance.BorderSize = 2;
            this.buttonRetrieveShowHotels.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonRetrieveShowHotels.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonRetrieveShowHotels.Location = new System.Drawing.Point(4, 92);
            this.buttonRetrieveShowHotels.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRetrieveShowHotels.Name = "buttonRetrieveShowHotels";
            this.buttonRetrieveShowHotels.Size = new System.Drawing.Size(195, 28);
            this.buttonRetrieveShowHotels.TabIndex = 51;
            this.buttonRetrieveShowHotels.Text = "Show All Hotels";
            this.buttonRetrieveShowHotels.UseVisualStyleBackColor = false;
            this.buttonRetrieveShowHotels.Click += new System.EventHandler(this.buttonRetrieveShowHotels_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(493, 79);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 17);
            this.label1.TabIndex = 57;
            this.label1.Text = "ID:";
            // 
            // HotellUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewShowwwHotels);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxSearchHotell);
            this.Controls.Add(this.buttonDeleteShowHotel);
            this.Controls.Add(this.buttonRetrieveShowHotels);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "HotellUserControl";
            this.Size = new System.Drawing.Size(894, 491);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowwwHotels)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewShowwwHotels;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxSearchHotell;
        private System.Windows.Forms.Button buttonDeleteShowHotel;
        private System.Windows.Forms.Button buttonRetrieveShowHotels;
        private System.Windows.Forms.Label label1;
    }
}
