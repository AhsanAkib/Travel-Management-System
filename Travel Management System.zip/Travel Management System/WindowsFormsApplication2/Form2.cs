﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            SidePanel2.Height = buttonShowCustomerInfo.Height;
            SidePanel2.Top = buttonShowCustomerInfo.Top;
            addUserControl1.BringToFront();
        }

        private void buttonShowCustomerInfo_Click(object sender, EventArgs e)
        {
            SidePanel2.Height = buttonShowCustomerInfo.Height;
            SidePanel2.Top = buttonShowCustomerInfo.Top;
            addUserControl1.BringToFront();
        }

        private void buttonShowTransportationInfo_Click(object sender, EventArgs e)
        {
            SidePanel2.Height = buttonShowTransportationInfo.Height;
            SidePanel2.Top = buttonShowTransportationInfo.Top;
            showTransportControl1.BringToFront();
        }

        private void buttonProfileAdmin_Click(object sender, EventArgs e)
        {
            SidePanel2.Height = buttonProfileAdmin.Height;
            SidePanel2.Top = buttonProfileAdmin.Top;
            adminProfileControl1.BringToFront();
        }

        private void buttonHotelInfo_Click(object sender, EventArgs e)
        {
            SidePanel2.Height = buttonHotelInfo.Height;
            SidePanel2.Top = buttonHotelInfo.Top;
            hotellUserControl1.BringToFront();
        }
    }
}
