﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class AdminProfileControl : UserControl
    {
        public AdminProfileControl()
        {
            InitializeComponent();
        }

        private void buttonAddNewAdmin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";

            string sql = "INSERT INTO RegAdmin(adminUsername,adminPassword) VALUES(@param1,@param2)";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();

                cmd.Parameters.Add("@param1", SqlDbType.NVarChar, 50).Value = textBoxNameAdmin.Text;
                cmd.Parameters.Add("@param2", SqlDbType.NVarChar, 50).Value = textBoxPasswordAdmin.Text;
                

                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                con.Close();
            }
        }
    }
}
