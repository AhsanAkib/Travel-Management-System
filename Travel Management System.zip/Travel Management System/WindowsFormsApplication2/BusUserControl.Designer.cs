﻿namespace WindowsFormsApplication2
{
    partial class BusUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonDoneBus = new System.Windows.Forms.Button();
            this.comboBoxFromBus = new System.Windows.Forms.ComboBox();
            this.comboBoxToBus = new System.Windows.Forms.ComboBox();
            this.dateTimePickerBus = new System.Windows.Forms.DateTimePicker();
            this.checkedListBoxSeatBus = new System.Windows.Forms.CheckedListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxClassBus = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonDoneBus
            // 
            this.buttonDoneBus.BackColor = System.Drawing.Color.White;
            this.buttonDoneBus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDoneBus.ForeColor = System.Drawing.Color.Black;
            this.buttonDoneBus.Location = new System.Drawing.Point(364, 321);
            this.buttonDoneBus.Name = "buttonDoneBus";
            this.buttonDoneBus.Size = new System.Drawing.Size(92, 28);
            this.buttonDoneBus.TabIndex = 4;
            this.buttonDoneBus.Text = "Done";
            this.buttonDoneBus.UseVisualStyleBackColor = false;
            // 
            // comboBoxFromBus
            // 
            this.comboBoxFromBus.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxFromBus.FormattingEnabled = true;
            this.comboBoxFromBus.Location = new System.Drawing.Point(133, 56);
            this.comboBoxFromBus.Name = "comboBoxFromBus";
            this.comboBoxFromBus.Size = new System.Drawing.Size(224, 24);
            this.comboBoxFromBus.TabIndex = 5;
            // 
            // comboBoxToBus
            // 
            this.comboBoxToBus.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxToBus.FormattingEnabled = true;
            this.comboBoxToBus.Location = new System.Drawing.Point(135, 120);
            this.comboBoxToBus.Name = "comboBoxToBus";
            this.comboBoxToBus.Size = new System.Drawing.Size(224, 24);
            this.comboBoxToBus.TabIndex = 6;
            // 
            // dateTimePickerBus
            // 
            this.dateTimePickerBus.Location = new System.Drawing.Point(135, 239);
            this.dateTimePickerBus.Name = "dateTimePickerBus";
            this.dateTimePickerBus.Size = new System.Drawing.Size(224, 22);
            this.dateTimePickerBus.TabIndex = 7;
            // 
            // checkedListBoxSeatBus
            // 
            this.checkedListBoxSeatBus.FormattingEnabled = true;
            this.checkedListBoxSeatBus.Items.AddRange(new object[] {
            "A1",
            "B1",
            "C1",
            "D1",
            "E1",
            "F1",
            "G1",
            "H1",
            "I1",
            "J1"});
            this.checkedListBoxSeatBus.Location = new System.Drawing.Point(574, 56);
            this.checkedListBoxSeatBus.Name = "checkedListBoxSeatBus";
            this.checkedListBoxSeatBus.Size = new System.Drawing.Size(120, 174);
            this.checkedListBoxSeatBus.TabIndex = 9;
            this.checkedListBoxSeatBus.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxSeatBus_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(50, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "From:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(446, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 17);
            this.label2.TabIndex = 11;
            this.label2.Text = "Available Seats:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(52, 124);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "To:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(52, 244);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 13;
            this.label4.Text = "Date:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(52, 183);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 26;
            this.label5.Text = "Class:";
            // 
            // comboBoxClassBus
            // 
            this.comboBoxClassBus.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxClassBus.FormattingEnabled = true;
            this.comboBoxClassBus.Location = new System.Drawing.Point(135, 179);
            this.comboBoxClassBus.Name = "comboBoxClassBus";
            this.comboBoxClassBus.Size = new System.Drawing.Size(224, 24);
            this.comboBoxClassBus.TabIndex = 25;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(57, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 36);
            this.label6.TabIndex = 27;
            this.label6.Text = "BUS:";
            // 
            // BusUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBoxClassBus);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePickerBus);
            this.Controls.Add(this.comboBoxToBus);
            this.Controls.Add(this.comboBoxFromBus);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkedListBoxSeatBus);
            this.Controls.Add(this.buttonDoneBus);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "BusUserControl";
            this.Size = new System.Drawing.Size(755, 390);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonDoneBus;
        private System.Windows.Forms.ComboBox comboBoxFromBus;
        private System.Windows.Forms.ComboBox comboBoxToBus;
        private System.Windows.Forms.DateTimePicker dateTimePickerBus;
        private System.Windows.Forms.CheckedListBox checkedListBoxSeatBus;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxClassBus;
        private System.Windows.Forms.Label label6;
    }
}
