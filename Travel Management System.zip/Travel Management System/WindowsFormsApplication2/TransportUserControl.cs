﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class TransportUserControl : UserControl
    {
        public TransportUserControl()
        {
            InitializeComponent();
        }

        private void buttonPlane_Click(object sender, EventArgs e)
        {
            this.Hide();
            PlaneForm pf = new PlaneForm();
            pf.ShowDialog();
        }

        private void buttonBus_Click(object sender, EventArgs e)
        {
            this.Hide();
            BusForm bf = new BusForm();
            bf.ShowDialog();
        }

    }
}
