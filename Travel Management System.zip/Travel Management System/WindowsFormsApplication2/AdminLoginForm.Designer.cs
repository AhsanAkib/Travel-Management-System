﻿namespace WindowsFormsApplication2
{
    partial class AdminLoginForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonAdminEnter = new System.Windows.Forms.Button();
            this.textBoxAdminID = new System.Windows.Forms.TextBox();
            this.textBoxAdminPasswordLogin = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonAdminEnter
            // 
            this.buttonAdminEnter.BackColor = System.Drawing.Color.Black;
            this.buttonAdminEnter.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonAdminEnter.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonAdminEnter.FlatAppearance.BorderSize = 2;
            this.buttonAdminEnter.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.buttonAdminEnter.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonAdminEnter.Location = new System.Drawing.Point(194, 280);
            this.buttonAdminEnter.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAdminEnter.Name = "buttonAdminEnter";
            this.buttonAdminEnter.Size = new System.Drawing.Size(100, 28);
            this.buttonAdminEnter.TabIndex = 25;
            this.buttonAdminEnter.Text = "Enter";
            this.buttonAdminEnter.UseVisualStyleBackColor = false;
            this.buttonAdminEnter.Click += new System.EventHandler(this.buttonAdminEnter_Click);
            // 
            // textBoxAdminID
            // 
            this.textBoxAdminID.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAdminID.Location = new System.Drawing.Point(205, 168);
            this.textBoxAdminID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAdminID.Name = "textBoxAdminID";
            this.textBoxAdminID.Size = new System.Drawing.Size(192, 22);
            this.textBoxAdminID.TabIndex = 24;
            // 
            // textBoxAdminPasswordLogin
            // 
            this.textBoxAdminPasswordLogin.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAdminPasswordLogin.Location = new System.Drawing.Point(205, 220);
            this.textBoxAdminPasswordLogin.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAdminPasswordLogin.Name = "textBoxAdminPasswordLogin";
            this.textBoxAdminPasswordLogin.Size = new System.Drawing.Size(192, 22);
            this.textBoxAdminPasswordLogin.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(50, 213);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(118, 29);
            this.label5.TabIndex = 22;
            this.label5.Text = "Password:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(50, 161);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(124, 29);
            this.label4.TabIndex = 21;
            this.label4.Text = "Username:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Snap ITC", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(170, 39);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(162, 51);
            this.label3.TabIndex = 20;
            this.label3.Text = "Admin";
            // 
            // AdminLoginForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(472, 450);
            this.Controls.Add(this.buttonAdminEnter);
            this.Controls.Add(this.textBoxAdminID);
            this.Controls.Add(this.textBoxAdminPasswordLogin);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "AdminLoginForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AdminLoginForm";
 //           this.Load += new System.EventHandler(this.AdminLoginForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonAdminEnter;
        private System.Windows.Forms.TextBox textBoxAdminID;
        private System.Windows.Forms.TextBox textBoxAdminPasswordLogin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
    }
}