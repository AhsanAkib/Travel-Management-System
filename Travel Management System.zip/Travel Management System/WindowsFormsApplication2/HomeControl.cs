﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class HomeControl : UserControl
    {
        public HomeControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Homee3 h3 = new Homee3();
            h3.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //packageUserControl1.BringToFront();
        }
    }
}
