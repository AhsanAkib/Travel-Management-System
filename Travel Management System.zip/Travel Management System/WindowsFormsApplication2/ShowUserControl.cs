﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class ShowUserControl : UserControl
    {
        public ShowUserControl()
        {
            InitializeComponent();
            string[] countries = new string[6];
            countries[0] = "Select a Country";
            countries[1] = "Bangladesh";
            countries[2] = "UK";
            countries[3] = "USA";
            countries[4] = "Canada";
            countries[5] = "Germany";

            comboBoxAddUserNationality.DataSource = countries;
        }

        private void buttonClearAddUser_Click(object sender, EventArgs e)
        {
            textBoxAddUserName.Text = "";
            textBoxAddUserID.Text = "";
            dateTimePickerAddUserDOB.Text = "";
            radioButtonAddUserMale.Checked = false;
            radioButtonAddUserFemale.Checked = false;
            comboBoxAddUserNationality.Text = "";
            textBoxAddUserEmail.Text = "";
            textBoxAddUserAddress.Text = "";
            textBoxAddUserPhone.Text = "";
            textBoxAddUserDesiredPassword.Text = "";
           
        }

        private void buttonRetrieveAddUser_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = .;" + "database = MyDatabase;" + "integrated security = SSPI";
            SqlCommand command = new SqlCommand("select * from RegTravel", con);
            con.Open();
            SqlDataReader DR = command.ExecuteReader();
            BindingSource source = new BindingSource();
            source.DataSource = DR;
            dataGridViewShowwUser.DataSource = source;
            con.Close();
        }

        private void buttonSignupAddUser_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";

            string sql = "INSERT INTO RegTravel(RegName,RegUserID,RegDOB,RegGender,RegNationality,RegEmail,RegAddress,RegPhone,RegPassword) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7,@param8,@param9)";
            using (SqlCommand cmd = new SqlCommand(sql, con))
            {

                con.Open();

                cmd.Parameters.Add("@param1", SqlDbType.NVarChar, 50).Value = textBoxAddUserName.Text;
                cmd.Parameters.Add("@param2", SqlDbType.NVarChar, 50).Value = textBoxAddUserID.Text;
                cmd.Parameters.Add("@param3", SqlDbType.Date).Value = dateTimePickerAddUserDOB.Text;

                if (radioButtonAddUserMale.Checked)
                {
                    cmd.Parameters.Add("@param4", SqlDbType.VarChar, 50).Value = "Male";
                }
                else
                {
                    cmd.Parameters.Add("@param4", SqlDbType.VarChar, 50).Value = "Female";
                }

                cmd.Parameters.Add("@param5", SqlDbType.NVarChar, 50).Value = comboBoxAddUserNationality.GetItemText(comboBoxAddUserNationality.SelectedItem);
                cmd.Parameters.Add("@param6", SqlDbType.NVarChar, 50).Value = textBoxAddUserEmail.Text;
                cmd.Parameters.Add("@param7", SqlDbType.NVarChar, 50).Value = textBoxAddUserAddress.Text;
                cmd.Parameters.Add("@param8", SqlDbType.NVarChar, 50).Value = textBoxAddUserPhone.Text;
                cmd.Parameters.Add("@param9", SqlDbType.NVarChar, 50).Value = textBoxAddUserDesiredPassword.Text;

                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();

                con.Close();


               
            }
        }

        private void buttonDeleteAddUser_Click(object sender, EventArgs e)
        {
            string constring = "data source =.;database = MyDatabase;integrated security = SSPI";
            string query = "DELETE FROM RegTravel WHERE RegUserID='" + textBoxAddUserID.Text + "'";
            SqlConnection conDatabase = new SqlConnection(constring);
            SqlCommand cmdDatabase = new SqlCommand(query, conDatabase);
            SqlDataReader myReader;

            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("Delete Successful");
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonUpdateAddUser_Click(object sender, EventArgs e)
        {
            string rb;
            if (radioButtonAddUserMale.Checked)
            {
                rb = radioButtonAddUserMale.Text;
            }
            else
            {
                rb = radioButtonAddUserFemale.Text;
            }
            
            string constring = "data source =.;database = MyDatabase;integrated security = SSPI";
            //string query = "UPDATE Library SET RegName='" + textBoxAddUserName.Text + "',RegDOB='"  + dateTimePickerAddUserDOB.Text + rb + "' WHERE RegUserID='" + textBoxAddUserID.Text + "'";
            string query = "UPDATE RegTravel SET RegName='" + textBoxAddUserName.Text +"',RegDOB='" + dateTimePickerAddUserDOB.Value.Date + "',RegGender='" + rb + "',RegNationality='" + comboBoxAddUserNationality.Text + "',RegEmail='" + textBoxAddUserEmail.Text + "',RegAddress='" + textBoxAddUserAddress.Text + "',RegPhone='" + textBoxAddUserPhone.Text + "',RegPassword='" + textBoxAddUserDesiredPassword.Text + "' WHERE RegUserID='" + textBoxAddUserID.Text + "'";
            SqlConnection conDatabase = new SqlConnection(constring);
            SqlCommand cmdDatabase = new SqlCommand(query, conDatabase);
            SqlDataReader myReader;

            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("Update Successful");
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
