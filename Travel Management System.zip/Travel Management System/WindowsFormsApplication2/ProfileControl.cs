﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class ProfileControl : UserControl
    {
        public ProfileControl()
        {
            InitializeComponent();
            string[] countries = new string[6];
            countries[0] = "Select a Country";
            countries[1] = "Bangladesh";
            countries[2] = "UK";
            countries[3] = "USA";
            countries[4] = "Canada";
            countries[5] = "Germany";

            comboBoxNationalityProfile.DataSource = countries;
        }

        private void buttonUpdateProfile_Click(object sender, EventArgs e)
        {
            string rb;
            if (radioButtonMaleProfile.Checked)
            {
                rb = radioButtonMaleProfile.Text;
            }
            else
            {
                rb = radioButtonFemaleProfile.Text;
            }

            string constring = "data source =.;database = MyDatabase;integrated security = SSPI";

            string query = "UPDATE RegTravel SET RegName='" + textBoxNameProfile.Text + "',RegDOB='" + dateTimePickerDOBProfile.Value.Date + "',RegGender='" + rb + "',RegNationality='" + comboBoxNationalityProfile.Text + "',RegEmail='" + textBoxEmailProfile.Text + "',RegAddress='" + textBoxAddressProfile.Text + "',RegPhone='" + textBoxPhoneProfile.Text + "',RegPassword='" + textBoxNewPasswordProfile.Text + "' WHERE RegPassword='" + textBoxOldPasswordProfile.Text + "'";

            //string query = "UPDATE RegTravel SET RegName='" + textBoxNameProfile.Text + "',RegDOB='" + dateTimePickerDOBProfile.Value.Date + "',RegGender='" + rb + "',RegNationality='" + comboBoxNationalityProfile.Text + "',RegEmail='" + textBoxEmailProfile.Text + "',RegAddress='" + textBoxAddressProfile.Text + "',RegPhone='" + textBoxPhoneProfile.Text + "',RegPassword='" + textBoxNewPasswordProfile.Text + "' WHERE RegUserID='" + textBoxOldPasswordProfile.Text + "'";

            SqlConnection conDatabase = new SqlConnection(constring);
            SqlCommand cmdDatabase = new SqlCommand(query, conDatabase);
            SqlDataReader myReader;

            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("Update Successful");
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
