﻿namespace WindowsFormsApplication2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.SidePanel2 = new System.Windows.Forms.Panel();
            this.buttonShowTransportationInfo = new System.Windows.Forms.Button();
            this.buttonShowCustomerInfo = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonProfileAdmin = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonHotelInfo = new System.Windows.Forms.Button();
            this.adminProfileControl1 = new WindowsFormsApplication2.AdminProfileControl();
            this.showTransportControl1 = new WindowsFormsApplication2.ShowTransportControl();
            this.addUserControl1 = new WindowsFormsApplication2.ShowUserControl();
            this.hotellUserControl1 = new WindowsFormsApplication2.HotellUserControl();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.buttonHotelInfo);
            this.panel1.Controls.Add(this.SidePanel2);
            this.panel1.Controls.Add(this.buttonShowTransportationInfo);
            this.panel1.Controls.Add(this.buttonShowCustomerInfo);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.buttonProfileAdmin);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(205, 593);
            this.panel1.TabIndex = 0;
            // 
            // SidePanel2
            // 
            this.SidePanel2.BackColor = System.Drawing.Color.MediumAquamarine;
            this.SidePanel2.Location = new System.Drawing.Point(4, 175);
            this.SidePanel2.Margin = new System.Windows.Forms.Padding(4);
            this.SidePanel2.Name = "SidePanel2";
            this.SidePanel2.Size = new System.Drawing.Size(14, 66);
            this.SidePanel2.TabIndex = 17;
            // 
            // buttonShowTransportationInfo
            // 
            this.buttonShowTransportationInfo.FlatAppearance.BorderSize = 0;
            this.buttonShowTransportationInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonShowTransportationInfo.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowTransportationInfo.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.buttonShowTransportationInfo.Image = ((System.Drawing.Image)(resources.GetObject("buttonShowTransportationInfo.Image")));
            this.buttonShowTransportationInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonShowTransportationInfo.Location = new System.Drawing.Point(8, 253);
            this.buttonShowTransportationInfo.Margin = new System.Windows.Forms.Padding(4);
            this.buttonShowTransportationInfo.Name = "buttonShowTransportationInfo";
            this.buttonShowTransportationInfo.Size = new System.Drawing.Size(189, 76);
            this.buttonShowTransportationInfo.TabIndex = 14;
            this.buttonShowTransportationInfo.Text = "Transportation Info";
            this.buttonShowTransportationInfo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonShowTransportationInfo.UseVisualStyleBackColor = true;
            this.buttonShowTransportationInfo.Click += new System.EventHandler(this.buttonShowTransportationInfo_Click);
            // 
            // buttonShowCustomerInfo
            // 
            this.buttonShowCustomerInfo.FlatAppearance.BorderSize = 0;
            this.buttonShowCustomerInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonShowCustomerInfo.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonShowCustomerInfo.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.buttonShowCustomerInfo.Image = ((System.Drawing.Image)(resources.GetObject("buttonShowCustomerInfo.Image")));
            this.buttonShowCustomerInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonShowCustomerInfo.Location = new System.Drawing.Point(16, 175);
            this.buttonShowCustomerInfo.Margin = new System.Windows.Forms.Padding(4);
            this.buttonShowCustomerInfo.Name = "buttonShowCustomerInfo";
            this.buttonShowCustomerInfo.Size = new System.Drawing.Size(189, 66);
            this.buttonShowCustomerInfo.TabIndex = 13;
            this.buttonShowCustomerInfo.Text = "Customer Info";
            this.buttonShowCustomerInfo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonShowCustomerInfo.UseVisualStyleBackColor = true;
            this.buttonShowCustomerInfo.Click += new System.EventHandler(this.buttonShowCustomerInfo_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(205, 165);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // buttonProfileAdmin
            // 
            this.buttonProfileAdmin.FlatAppearance.BorderSize = 0;
            this.buttonProfileAdmin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonProfileAdmin.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonProfileAdmin.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.buttonProfileAdmin.Image = ((System.Drawing.Image)(resources.GetObject("buttonProfileAdmin.Image")));
            this.buttonProfileAdmin.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonProfileAdmin.Location = new System.Drawing.Point(0, 421);
            this.buttonProfileAdmin.Margin = new System.Windows.Forms.Padding(4);
            this.buttonProfileAdmin.Name = "buttonProfileAdmin";
            this.buttonProfileAdmin.Size = new System.Drawing.Size(189, 66);
            this.buttonProfileAdmin.TabIndex = 5;
            this.buttonProfileAdmin.Text = "   Add Admin";
            this.buttonProfileAdmin.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonProfileAdmin.UseVisualStyleBackColor = true;
            this.buttonProfileAdmin.Click += new System.EventHandler(this.buttonProfileAdmin_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.MediumAquamarine;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(205, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(872, 31);
            this.panel3.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DimGray;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel2.Location = new System.Drawing.Point(293, 1);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(152, 161);
            this.panel2.TabIndex = 12;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(23, 126);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 17);
            this.label2.TabIndex = 12;
            this.label2.Text = " Travel Anywhere";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(27, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(95, 94);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mistral", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 102);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 22);
            this.label1.TabIndex = 0;
            this.label1.Text = "ARNS Travels";
            // 
            // buttonHotelInfo
            // 
            this.buttonHotelInfo.FlatAppearance.BorderSize = 0;
            this.buttonHotelInfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHotelInfo.Font = new System.Drawing.Font("Century", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonHotelInfo.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.buttonHotelInfo.Image = ((System.Drawing.Image)(resources.GetObject("buttonHotelInfo.Image")));
            this.buttonHotelInfo.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonHotelInfo.Location = new System.Drawing.Point(12, 337);
            this.buttonHotelInfo.Margin = new System.Windows.Forms.Padding(4);
            this.buttonHotelInfo.Name = "buttonHotelInfo";
            this.buttonHotelInfo.Size = new System.Drawing.Size(189, 76);
            this.buttonHotelInfo.TabIndex = 18;
            this.buttonHotelInfo.Text = "   Hotel Info";
            this.buttonHotelInfo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.buttonHotelInfo.UseVisualStyleBackColor = true;
            this.buttonHotelInfo.Click += new System.EventHandler(this.buttonHotelInfo_Click);
            // 
            // adminProfileControl1
            // 
            this.adminProfileControl1.AutoScroll = true;
            this.adminProfileControl1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.adminProfileControl1.ForeColor = System.Drawing.Color.White;
            this.adminProfileControl1.Location = new System.Drawing.Point(205, 161);
            this.adminProfileControl1.Name = "adminProfileControl1";
            this.adminProfileControl1.Size = new System.Drawing.Size(873, 446);
            this.adminProfileControl1.TabIndex = 17;
            // 
            // showTransportControl1
            // 
            this.showTransportControl1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.showTransportControl1.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.showTransportControl1.Location = new System.Drawing.Point(205, 161);
            this.showTransportControl1.Name = "showTransportControl1";
            this.showTransportControl1.Size = new System.Drawing.Size(873, 432);
            this.showTransportControl1.TabIndex = 16;
            // 
            // addUserControl1
            // 
            this.addUserControl1.AutoScroll = true;
            this.addUserControl1.BackColor = System.Drawing.Color.Black;
            this.addUserControl1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.addUserControl1.Location = new System.Drawing.Point(205, 161);
            this.addUserControl1.Margin = new System.Windows.Forms.Padding(4);
            this.addUserControl1.Name = "addUserControl1";
            this.addUserControl1.Size = new System.Drawing.Size(872, 432);
            this.addUserControl1.TabIndex = 14;
            // 
            // hotellUserControl1
            // 
            this.hotellUserControl1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hotellUserControl1.ForeColor = System.Drawing.Color.White;
            this.hotellUserControl1.Location = new System.Drawing.Point(204, 161);
            this.hotellUserControl1.Name = "hotellUserControl1";
            this.hotellUserControl1.Size = new System.Drawing.Size(873, 432);
            this.hotellUserControl1.TabIndex = 18;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1077, 593);
            this.Controls.Add(this.hotellUserControl1);
            this.Controls.Add(this.adminProfileControl1);
            this.Controls.Add(this.showTransportControl1);
            this.Controls.Add(this.addUserControl1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ARNS Travels";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonProfileAdmin;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button buttonShowCustomerInfo;
        private ShowUserControl addUserControl1;
        private System.Windows.Forms.Button buttonShowTransportationInfo;
        private ShowTransportControl showTransportControl1;
        private System.Windows.Forms.Panel SidePanel2;
        private AdminProfileControl adminProfileControl1;
        private System.Windows.Forms.Button buttonHotelInfo;
        private HotellUserControl hotellUserControl1;
    }
}