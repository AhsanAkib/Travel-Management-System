﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class AdminLoginForm : Form
    {
        public AdminLoginForm()
        {
            InitializeComponent();
        }

        private void buttonAdminEnter_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";

            string sql = "Select * FROM RegAdmin WHERE adminUsername='" + textBoxAdminID.Text + "' and adminPassword='" + textBoxAdminPasswordLogin.Text + "'";
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataTable dtb1 = new DataTable();
            sda.Fill(dtb1);
            if (dtb1.Rows.Count == 1)
            {
                Form2 f2 = new Form2();
                this.Hide();
                f2.Show();
            }
            else
            {
                MessageBox.Show("Wrong UserId & Password!");
            }
        }
    }
}
