﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class HotelDetails : Form
    {
        public HotelDetails()
        {
            InitializeComponent();
        }

        private void buttonDoneHotelDetails_Click(object sender, EventArgs e)
        {
           try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";

                string sql = "INSERT INTO RegHotel(hotelCheckin,hotelCheckout,hotelRooms,hotelName) VALUES(@param1,@param2,@param3,@param4)";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {

                    con.Open();
                    cmd.Parameters.Add("@param1", SqlDbType.Date).Value = dateTimePickerHotelCheckIn.Text;
                    cmd.Parameters.Add("@param2", SqlDbType.Date).Value = dateTimePickerHotelCheckOut.Text;
                    try
                    {
                        string str = "";
                        if (checkedListBoxHotelDetails.CheckedItems.Count > 0)
                        {
                            for (int i = 0; i < checkedListBoxHotelDetails.CheckedItems.Count; i++)
                            {

                                if (str == "")
                                {
                                    str = checkedListBoxHotelDetails.CheckedItems[i].ToString();
                                }
                                else
                                {
                                    str += "," + checkedListBoxHotelDetails.CheckedItems[i].ToString();

                                }
                            }

                            cmd.Parameters.Add("@param3", SqlDbType.NVarChar, 50).Value = str;
                            cmd.Parameters.Add("@param4", SqlDbType.NVarChar, 50).Value = "SLS Hotel";

                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message + ex.ToString());
                    }

                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    con.Close();

                    this.Hide();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Rooms are taken, select another seat!");
            }
        }
    }
}
