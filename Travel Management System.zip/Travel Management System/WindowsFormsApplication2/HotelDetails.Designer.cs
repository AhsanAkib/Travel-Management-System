﻿namespace WindowsFormsApplication2
{
    partial class HotelDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonDoneHotelDetails = new System.Windows.Forms.Button();
            this.checkedListBoxHotelDetails = new System.Windows.Forms.CheckedListBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerHotelCheckIn = new System.Windows.Forms.DateTimePicker();
            this.dateTimePickerHotelCheckOut = new System.Windows.Forms.DateTimePicker();
            this.SuspendLayout();
            // 
            // buttonDoneHotelDetails
            // 
            this.buttonDoneHotelDetails.BackColor = System.Drawing.Color.White;
            this.buttonDoneHotelDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDoneHotelDetails.ForeColor = System.Drawing.Color.Black;
            this.buttonDoneHotelDetails.Location = new System.Drawing.Point(347, 380);
            this.buttonDoneHotelDetails.Name = "buttonDoneHotelDetails";
            this.buttonDoneHotelDetails.Size = new System.Drawing.Size(123, 39);
            this.buttonDoneHotelDetails.TabIndex = 42;
            this.buttonDoneHotelDetails.Text = "Done";
            this.buttonDoneHotelDetails.UseVisualStyleBackColor = false;
            this.buttonDoneHotelDetails.Click += new System.EventHandler(this.buttonDoneHotelDetails_Click);
            // 
            // checkedListBoxHotelDetails
            // 
            this.checkedListBoxHotelDetails.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.checkedListBoxHotelDetails.FormattingEnabled = true;
            this.checkedListBoxHotelDetails.Items.AddRange(new object[] {
            "A1",
            "A2",
            "B1",
            "B2",
            "C1",
            "C2",
            "D1",
            "D2",
            "E1",
            "E2",
            "F1",
            "F2"});
            this.checkedListBoxHotelDetails.Location = new System.Drawing.Point(582, 114);
            this.checkedListBoxHotelDetails.Name = "checkedListBoxHotelDetails";
            this.checkedListBoxHotelDetails.Size = new System.Drawing.Size(143, 225);
            this.checkedListBoxHotelDetails.TabIndex = 37;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(452, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(117, 17);
            this.label6.TabIndex = 34;
            this.label6.Text = "Available Rooms:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 227);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 17);
            this.label3.TabIndex = 31;
            this.label3.Text = "Check-Out:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 17);
            this.label2.TabIndex = 30;
            this.label2.Text = "Check-In:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(231, 36);
            this.label1.TabIndex = 29;
            this.label1.Text = "Hotel Details";
            // 
            // dateTimePickerHotelCheckIn
            // 
            this.dateTimePickerHotelCheckIn.Location = new System.Drawing.Point(164, 169);
            this.dateTimePickerHotelCheckIn.Name = "dateTimePickerHotelCheckIn";
            this.dateTimePickerHotelCheckIn.Size = new System.Drawing.Size(226, 22);
            this.dateTimePickerHotelCheckIn.TabIndex = 43;
            // 
            // dateTimePickerHotelCheckOut
            // 
            this.dateTimePickerHotelCheckOut.Location = new System.Drawing.Point(163, 227);
            this.dateTimePickerHotelCheckOut.Name = "dateTimePickerHotelCheckOut";
            this.dateTimePickerHotelCheckOut.Size = new System.Drawing.Size(226, 22);
            this.dateTimePickerHotelCheckOut.TabIndex = 44;
            // 
            // HotelDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dateTimePickerHotelCheckOut);
            this.Controls.Add(this.dateTimePickerHotelCheckIn);
            this.Controls.Add(this.buttonDoneHotelDetails);
            this.Controls.Add(this.checkedListBoxHotelDetails);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "HotelDetails";
            this.Text = "HotelDetails";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonDoneHotelDetails;
        private System.Windows.Forms.CheckedListBox checkedListBoxHotelDetails;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePickerHotelCheckIn;
        private System.Windows.Forms.DateTimePicker dateTimePickerHotelCheckOut;
    }
}