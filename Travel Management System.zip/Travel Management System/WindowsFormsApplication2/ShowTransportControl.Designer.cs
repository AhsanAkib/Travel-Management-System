﻿namespace WindowsFormsApplication2
{
    partial class ShowTransportControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.buttonDeleteShowTransport = new System.Windows.Forms.Button();
            this.buttonRetrieveShowTransport = new System.Windows.Forms.Button();
            this.textBoxSearchTransport = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewShowwwTransport = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowwwTransport)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonDeleteShowTransport
            // 
            this.buttonDeleteShowTransport.BackColor = System.Drawing.Color.Black;
            this.buttonDeleteShowTransport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDeleteShowTransport.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonDeleteShowTransport.FlatAppearance.BorderSize = 2;
            this.buttonDeleteShowTransport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonDeleteShowTransport.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonDeleteShowTransport.Location = new System.Drawing.Point(756, 122);
            this.buttonDeleteShowTransport.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDeleteShowTransport.Name = "buttonDeleteShowTransport";
            this.buttonDeleteShowTransport.Size = new System.Drawing.Size(75, 28);
            this.buttonDeleteShowTransport.TabIndex = 45;
            this.buttonDeleteShowTransport.Text = "Delete";
            this.buttonDeleteShowTransport.UseVisualStyleBackColor = false;
            this.buttonDeleteShowTransport.Click += new System.EventHandler(this.buttonDeleteShowTransport_Click);
            // 
            // buttonRetrieveShowTransport
            // 
            this.buttonRetrieveShowTransport.BackColor = System.Drawing.Color.Black;
            this.buttonRetrieveShowTransport.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonRetrieveShowTransport.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonRetrieveShowTransport.FlatAppearance.BorderSize = 2;
            this.buttonRetrieveShowTransport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonRetrieveShowTransport.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonRetrieveShowTransport.Location = new System.Drawing.Point(4, 107);
            this.buttonRetrieveShowTransport.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRetrieveShowTransport.Name = "buttonRetrieveShowTransport";
            this.buttonRetrieveShowTransport.Size = new System.Drawing.Size(195, 28);
            this.buttonRetrieveShowTransport.TabIndex = 44;
            this.buttonRetrieveShowTransport.Text = "Show All Transportation";
            this.buttonRetrieveShowTransport.UseVisualStyleBackColor = false;
            this.buttonRetrieveShowTransport.Click += new System.EventHandler(this.buttonRetrieveShowTransport_Click);
            // 
            // textBoxSearchTransport
            // 
            this.textBoxSearchTransport.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxSearchTransport.Location = new System.Drawing.Point(551, 92);
            this.textBoxSearchTransport.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxSearchTransport.Name = "textBoxSearchTransport";
            this.textBoxSearchTransport.Size = new System.Drawing.Size(280, 22);
            this.textBoxSearchTransport.TabIndex = 46;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Snap ITC", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(147, 26);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(557, 51);
            this.label3.TabIndex = 48;
            this.label3.Text = "Booked Transportaions";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(267, 289);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(240, 150);
            this.dataGridView1.TabIndex = 49;
            // 
            // dataGridViewShowwwTransport
            // 
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewShowwwTransport.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewShowwwTransport.BackgroundColor = System.Drawing.SystemColors.ActiveBorder;
            this.dataGridViewShowwwTransport.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridViewShowwwTransport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowwwTransport.GridColor = System.Drawing.Color.Black;
            this.dataGridViewShowwwTransport.Location = new System.Drawing.Point(0, 199);
            this.dataGridViewShowwwTransport.Name = "dataGridViewShowwwTransport";
            this.dataGridViewShowwwTransport.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dataGridViewShowwwTransport.RowHeadersWidth = 51;
            this.dataGridViewShowwwTransport.RowTemplate.Height = 24;
            this.dataGridViewShowwwTransport.Size = new System.Drawing.Size(894, 292);
            this.dataGridViewShowwwTransport.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(497, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 17);
            this.label1.TabIndex = 51;
            this.label1.Text = "ID:";
            // 
            // ShowTransportControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewShowwwTransport);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.textBoxSearchTransport);
            this.Controls.Add(this.buttonDeleteShowTransport);
            this.Controls.Add(this.buttonRetrieveShowTransport);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "ShowTransportControl";
            this.Size = new System.Drawing.Size(894, 491);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowwwTransport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonDeleteShowTransport;
        private System.Windows.Forms.Button buttonRetrieveShowTransport;
        private System.Windows.Forms.TextBox textBoxSearchTransport;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridViewShowwwTransport;
        private System.Windows.Forms.Label label1;
    }
}
