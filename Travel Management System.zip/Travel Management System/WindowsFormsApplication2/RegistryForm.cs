﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class RegistryForm : Form
    {
        public RegistryForm()
        {
            InitializeComponent();
            string[] countries = new string[6];
            countries[0] = "Select a Country";
            countries[1] = "Bangladesh";
            countries[2] = "UK";
            countries[3] = "USA";
            countries[4] = "Canada";
            countries[5] = "Germany";

            comboBoxNationality.DataSource = countries;
        }



        private void buttonSignup_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";

                string sql = "INSERT INTO RegTravel(RegName,RegUserID,RegDOB,RegGender,RegNationality,RegEmail,RegAddress,RegPhone,RegPassword) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7,@param8,@param9)";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {

                    con.Open();

                    cmd.Parameters.Add("@param1", SqlDbType.NVarChar, 50).Value = textBoxNameRegistration.Text;
                    cmd.Parameters.Add("@param2", SqlDbType.NVarChar, 50).Value = textBoxIDRegistration.Text;
                    cmd.Parameters.Add("@param3", SqlDbType.Date).Value = dateTimePickerDOBRegistration.Text;

                    if (radioButtonMale.Checked)
                    {
                        cmd.Parameters.Add("@param4", SqlDbType.VarChar, 50).Value = "Male";
                    }
                    else
                    {
                        cmd.Parameters.Add("@param4", SqlDbType.VarChar, 50).Value = "Female";
                    }

                    cmd.Parameters.Add("@param5", SqlDbType.NVarChar, 50).Value = comboBoxNationality.GetItemText(comboBoxNationality.SelectedItem);
                    cmd.Parameters.Add("@param6", SqlDbType.NVarChar, 50).Value = textBoxEmail.Text;
                    cmd.Parameters.Add("@param7", SqlDbType.NVarChar, 50).Value = textBoxAddress.Text;
                    cmd.Parameters.Add("@param8", SqlDbType.NVarChar, 50).Value = textBoxPhone.Text;
                    cmd.Parameters.Add("@param9", SqlDbType.NVarChar, 50).Value = textBoxDesiredPassword.Text;

                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    con.Close();


                    LoginForm lff1 = new LoginForm();
                    this.Hide();
                    lff1.Show();
                }
            }
             catch(Exception exception)
            {
                MessageBox.Show("User ID taken, try another UserID");
                LoginForm lff1 = new LoginForm();
                this.Hide();
                lff1.Show();
            }
           
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm llff1 = new LoginForm();
            llff1.Show();

        }
    }
}