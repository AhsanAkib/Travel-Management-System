﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class PlaneForm : Form
    {
        public PlaneForm()
        {
            InitializeComponent();
            string[] countries = new string[6];
            countries[0] = "Select a Country";
            countries[1] = "Bangladesh";
            countries[2] = "UK";
            countries[3] = "USA";
            countries[4] = "Canada";
            countries[5] = "Germany";
            comboBoxPlaneFrom.DataSource = countries;

            string[] countries2 = new string[6];
            countries2[0] = "Select a Country";
            countries2[1] = "Bangladesh";
            countries2[2] = "UK";
            countries2[3] = "USA";
            countries2[4] = "Canada";
            countries2[5] = "Germany";
            comboBoxPlaneTo.DataSource = countries2;
            
            string[] classs = new string[3];
            classs[0] = "Select a Class";
            classs[1] = "Business";
            classs[2] = "Economy";
            comboBoxPlaneClass.DataSource=classs;

            string[] time = new string[3];
            time[0] = "Select a Time";
            time[1] = "10 AM";
            time[2] = "10 PM";
            comboBoxPlaneTime.DataSource = time;

        }

        private Button buttonPlaneDone;
        private DateTimePicker dateTimePickerPlaneDate;
        private ComboBox comboBoxPlaneTime;
        private ComboBox comboBoxPlaneClass;
        private ComboBox comboBoxPlaneTo;
        private CheckedListBox checkedListBoxPlaneSeats;
        private ComboBox comboBoxPlaneFrom;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;

        private void InitializeComponent()
        {
            this.buttonPlaneDone = new System.Windows.Forms.Button();
            this.dateTimePickerPlaneDate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxPlaneTime = new System.Windows.Forms.ComboBox();
            this.comboBoxPlaneClass = new System.Windows.Forms.ComboBox();
            this.comboBoxPlaneTo = new System.Windows.Forms.ComboBox();
            this.checkedListBoxPlaneSeats = new System.Windows.Forms.CheckedListBox();
            this.comboBoxPlaneFrom = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonPlaneDone
            // 
            this.buttonPlaneDone.BackColor = System.Drawing.Color.White;
            this.buttonPlaneDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlaneDone.ForeColor = System.Drawing.Color.Black;
            this.buttonPlaneDone.Location = new System.Drawing.Point(347, 380);
            this.buttonPlaneDone.Name = "buttonPlaneDone";
            this.buttonPlaneDone.Size = new System.Drawing.Size(123, 39);
            this.buttonPlaneDone.TabIndex = 42;
            this.buttonPlaneDone.Text = "Done";
            this.buttonPlaneDone.UseVisualStyleBackColor = false;
            this.buttonPlaneDone.Click += new System.EventHandler(this.buttonPlaneDone_Click);
            // 
            // dateTimePickerPlaneDate
            // 
            this.dateTimePickerPlaneDate.Location = new System.Drawing.Point(164, 322);
            this.dateTimePickerPlaneDate.Name = "dateTimePickerPlaneDate";
            this.dateTimePickerPlaneDate.Size = new System.Drawing.Size(226, 22);
            this.dateTimePickerPlaneDate.TabIndex = 41;
            // 
            // comboBoxPlaneTime
            // 
            this.comboBoxPlaneTime.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxPlaneTime.FormattingEnabled = true;
            this.comboBoxPlaneTime.Location = new System.Drawing.Point(164, 270);
            this.comboBoxPlaneTime.Name = "comboBoxPlaneTime";
            this.comboBoxPlaneTime.Size = new System.Drawing.Size(226, 24);
            this.comboBoxPlaneTime.TabIndex = 40;
            // 
            // comboBoxPlaneClass
            // 
            this.comboBoxPlaneClass.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxPlaneClass.FormattingEnabled = true;
            this.comboBoxPlaneClass.Location = new System.Drawing.Point(164, 215);
            this.comboBoxPlaneClass.Name = "comboBoxPlaneClass";
            this.comboBoxPlaneClass.Size = new System.Drawing.Size(226, 24);
            this.comboBoxPlaneClass.TabIndex = 39;
            // 
            // comboBoxPlaneTo
            // 
            this.comboBoxPlaneTo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxPlaneTo.FormattingEnabled = true;
            this.comboBoxPlaneTo.Location = new System.Drawing.Point(164, 166);
            this.comboBoxPlaneTo.Name = "comboBoxPlaneTo";
            this.comboBoxPlaneTo.Size = new System.Drawing.Size(226, 24);
            this.comboBoxPlaneTo.TabIndex = 38;
            // 
            // checkedListBoxPlaneSeats
            // 
            this.checkedListBoxPlaneSeats.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.checkedListBoxPlaneSeats.FormattingEnabled = true;
            this.checkedListBoxPlaneSeats.Items.AddRange(new object[] {
            "A1",
            "A2",
            "B1",
            "B2",
            "C1",
            "C2",
            "D1",
            "D2",
            "E1",
            "E2",
            "F1",
            "F2"});
            this.checkedListBoxPlaneSeats.Location = new System.Drawing.Point(582, 114);
            this.checkedListBoxPlaneSeats.Name = "checkedListBoxPlaneSeats";
            this.checkedListBoxPlaneSeats.Size = new System.Drawing.Size(143, 225);
            this.checkedListBoxPlaneSeats.TabIndex = 37;
            // 
            // comboBoxPlaneFrom
            // 
            this.comboBoxPlaneFrom.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxPlaneFrom.FormattingEnabled = true;
            this.comboBoxPlaneFrom.Location = new System.Drawing.Point(164, 114);
            this.comboBoxPlaneFrom.Name = "comboBoxPlaneFrom";
            this.comboBoxPlaneFrom.Size = new System.Drawing.Size(226, 24);
            this.comboBoxPlaneFrom.TabIndex = 36;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(78, 270);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 17);
            this.label7.TabIndex = 35;
            this.label7.Text = "Time:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(452, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 17);
            this.label6.TabIndex = 34;
            this.label6.Text = "Available Seats:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(78, 322);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 17);
            this.label5.TabIndex = 33;
            this.label5.Text = "Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 218);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 32;
            this.label4.Text = "Class:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 17);
            this.label3.TabIndex = 31;
            this.label3.Text = "To:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 17);
            this.label2.TabIndex = 30;
            this.label2.Text = "From:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 36);
            this.label1.TabIndex = 29;
            this.label1.Text = "PLANE";
            // 
            // PlaneForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonPlaneDone);
            this.Controls.Add(this.dateTimePickerPlaneDate);
            this.Controls.Add(this.comboBoxPlaneTime);
            this.Controls.Add(this.comboBoxPlaneClass);
            this.Controls.Add(this.comboBoxPlaneTo);
            this.Controls.Add(this.checkedListBoxPlaneSeats);
            this.Controls.Add(this.comboBoxPlaneFrom);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "PlaneForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PlaneForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void buttonPlaneDone_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";

                string sql = "INSERT INTO RegTransport(transportFrom,transportTo,transportClass,transportTime,transportDate,transportSeat,transportType) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7)";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {

                    con.Open();

                    cmd.Parameters.Add("@param1", SqlDbType.NVarChar, 50).Value = comboBoxPlaneFrom.GetItemText(comboBoxPlaneFrom.SelectedItem);
                    cmd.Parameters.Add("@param2", SqlDbType.NVarChar, 50).Value = comboBoxPlaneTo.GetItemText(comboBoxPlaneTo.SelectedItem);
                    cmd.Parameters.Add("@param3", SqlDbType.NVarChar, 50).Value = comboBoxPlaneClass.GetItemText(comboBoxPlaneClass.SelectedItem);
                    cmd.Parameters.Add("@param4", SqlDbType.NVarChar, 50).Value = comboBoxPlaneTime.GetItemText(comboBoxPlaneTime.SelectedItem);
                    cmd.Parameters.Add("@param5", SqlDbType.Date).Value = dateTimePickerPlaneDate.Text;
                    cmd.Parameters.Add("@param7", SqlDbType.NVarChar, 50).Value = "Plane";


                    try
                    {
                        string str = "";
                        if (checkedListBoxPlaneSeats.CheckedItems.Count > 0)
                        {
                            for (int i = 0; i < checkedListBoxPlaneSeats.CheckedItems.Count; i++)
                            {

                                if (str == "")
                                {
                                    str = checkedListBoxPlaneSeats.CheckedItems[i].ToString();
                                }
                                else
                                {
                                    str += "," + checkedListBoxPlaneSeats.CheckedItems[i].ToString();

                                }
                            }

                            cmd.Parameters.Add("@param6", SqlDbType.NVarChar, 50).Value = str;
                            //cmd.Parameters.AddWithValue("@param6", SqlDbType.NVarChar, 50).Value=str);
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message + ex.ToString());
                    }

                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    con.Close();


                    LoginForm lff1 = new LoginForm();
                    this.Hide();
                    lff1.Show();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Seats are taken, select another seat!");
            }
        }
    }
}
