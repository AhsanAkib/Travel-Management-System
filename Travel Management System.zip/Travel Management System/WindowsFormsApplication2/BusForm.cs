﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class BusForm : Form
    {
        public BusForm()
        {
            InitializeComponent();

            string[] countries = new string[6];
            countries[0] = "Select a Country";
            countries[1] = "Bangladesh";
            countries[2] = "UK";
            countries[3] = "USA";
            countries[4] = "Canada";
            countries[5] = "Germany";
            comboBoxBusFrom.DataSource = countries;

            string[] countries2 = new string[6];
            countries2[0] = "Select a Country";
            countries2[1] = "Bangladesh";
            countries2[2] = "UK";
            countries2[3] = "USA";
            countries2[4] = "Canada";
            countries2[5] = "Germany";
            comboBoxBusTo.DataSource = countries2;

            string[] classs = new string[3];
            classs[0] = "Select a Class";
            classs[1] = "Business";
            classs[2] = "Economy";
            comboBoxBusClass.DataSource = classs;

            string[] time = new string[3];
            time[0] = "Select a Time";
            time[1] = "10 AM";
            time[2] = "10 PM";
            comboBoxBusTime.DataSource = time;
        }

        private Button buttonBusDone;
        private DateTimePicker dateTimePickerBusDate;
        private ComboBox comboBoxBusTime;
        private ComboBox comboBoxBusClass;
        private ComboBox comboBoxBusTo;
        private CheckedListBox checkedListBoxBusSeats;
        private ComboBox comboBoxBusFrom;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;

        private void InitializeComponent()
        {
            this.buttonBusDone = new System.Windows.Forms.Button();
            this.dateTimePickerBusDate = new System.Windows.Forms.DateTimePicker();
            this.comboBoxBusTime = new System.Windows.Forms.ComboBox();
            this.comboBoxBusClass = new System.Windows.Forms.ComboBox();
            this.comboBoxBusTo = new System.Windows.Forms.ComboBox();
            this.checkedListBoxBusSeats = new System.Windows.Forms.CheckedListBox();
            this.comboBoxBusFrom = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonBusDone
            // 
            this.buttonBusDone.BackColor = System.Drawing.Color.White;
            this.buttonBusDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBusDone.ForeColor = System.Drawing.Color.Black;
            this.buttonBusDone.Location = new System.Drawing.Point(347, 380);
            this.buttonBusDone.Name = "buttonBusDone";
            this.buttonBusDone.Size = new System.Drawing.Size(123, 39);
            this.buttonBusDone.TabIndex = 28;
            this.buttonBusDone.Text = "Done";
            this.buttonBusDone.UseVisualStyleBackColor = false;
            this.buttonBusDone.Click += new System.EventHandler(this.buttonBusDone_Click);
            // 
            // dateTimePickerBusDate
            // 
            this.dateTimePickerBusDate.Location = new System.Drawing.Point(164, 322);
            this.dateTimePickerBusDate.Name = "dateTimePickerBusDate";
            this.dateTimePickerBusDate.Size = new System.Drawing.Size(226, 22);
            this.dateTimePickerBusDate.TabIndex = 27;
            // 
            // comboBoxBusTime
            // 
            this.comboBoxBusTime.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxBusTime.FormattingEnabled = true;
            this.comboBoxBusTime.Location = new System.Drawing.Point(164, 270);
            this.comboBoxBusTime.Name = "comboBoxBusTime";
            this.comboBoxBusTime.Size = new System.Drawing.Size(226, 24);
            this.comboBoxBusTime.TabIndex = 26;
            // 
            // comboBoxBusClass
            // 
            this.comboBoxBusClass.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxBusClass.FormattingEnabled = true;
            this.comboBoxBusClass.Location = new System.Drawing.Point(164, 215);
            this.comboBoxBusClass.Name = "comboBoxBusClass";
            this.comboBoxBusClass.Size = new System.Drawing.Size(226, 24);
            this.comboBoxBusClass.TabIndex = 25;
            // 
            // comboBoxBusTo
            // 
            this.comboBoxBusTo.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxBusTo.FormattingEnabled = true;
            this.comboBoxBusTo.Location = new System.Drawing.Point(164, 166);
            this.comboBoxBusTo.Name = "comboBoxBusTo";
            this.comboBoxBusTo.Size = new System.Drawing.Size(226, 24);
            this.comboBoxBusTo.TabIndex = 24;
            // 
            // checkedListBoxBusSeats
            // 
            this.checkedListBoxBusSeats.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.checkedListBoxBusSeats.FormattingEnabled = true;
            this.checkedListBoxBusSeats.Items.AddRange(new object[] {
            "A1",
            "A2",
            "B1",
            "B2",
            "C1",
            "C2",
            "D1",
            "D2",
            "E1",
            "E2",
            "F1",
            "F2"});
            this.checkedListBoxBusSeats.Location = new System.Drawing.Point(582, 114);
            this.checkedListBoxBusSeats.Name = "checkedListBoxBusSeats";
            this.checkedListBoxBusSeats.Size = new System.Drawing.Size(143, 225);
            this.checkedListBoxBusSeats.TabIndex = 23;
            // 
            // comboBoxBusFrom
            // 
            this.comboBoxBusFrom.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxBusFrom.FormattingEnabled = true;
            this.comboBoxBusFrom.Location = new System.Drawing.Point(164, 114);
            this.comboBoxBusFrom.Name = "comboBoxBusFrom";
            this.comboBoxBusFrom.Size = new System.Drawing.Size(226, 24);
            this.comboBoxBusFrom.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(78, 270);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 17);
            this.label7.TabIndex = 21;
            this.label7.Text = "Time:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(452, 114);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 17);
            this.label6.TabIndex = 20;
            this.label6.Text = "Available Seats:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(78, 322);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 17);
            this.label5.TabIndex = 19;
            this.label5.Text = "Date:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(78, 218);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 17);
            this.label4.TabIndex = 18;
            this.label4.Text = "Class:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(78, 166);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 17);
            this.label3.TabIndex = 17;
            this.label3.Text = "To:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(78, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 17);
            this.label2.TabIndex = 16;
            this.label2.Text = "From:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 36);
            this.label1.TabIndex = 15;
            this.label1.Text = "BUS";
            // 
            // BusForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonBusDone);
            this.Controls.Add(this.dateTimePickerBusDate);
            this.Controls.Add(this.comboBoxBusTime);
            this.Controls.Add(this.comboBoxBusClass);
            this.Controls.Add(this.comboBoxBusTo);
            this.Controls.Add(this.checkedListBoxBusSeats);
            this.Controls.Add(this.comboBoxBusFrom);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "BusForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BusForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private void buttonBusDone_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";

                string sql = "INSERT INTO RegTransport(transportFrom,transportTo,transportClass,transportTime,transportDate,transportSeat,transportType) VALUES(@param1,@param2,@param3,@param4,@param5,@param6,@param7)";
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {

                    con.Open();

                    cmd.Parameters.Add("@param1", SqlDbType.NVarChar, 50).Value = comboBoxBusFrom.GetItemText(comboBoxBusFrom.SelectedItem);
                    cmd.Parameters.Add("@param2", SqlDbType.NVarChar, 50).Value = comboBoxBusTo.GetItemText(comboBoxBusTo.SelectedItem);
                    cmd.Parameters.Add("@param3", SqlDbType.NVarChar, 50).Value = comboBoxBusClass.GetItemText(comboBoxBusClass.SelectedItem);
                    cmd.Parameters.Add("@param4", SqlDbType.NVarChar, 50).Value = comboBoxBusTime.GetItemText(comboBoxBusTime.SelectedItem);
                    cmd.Parameters.Add("@param5", SqlDbType.Date).Value = dateTimePickerBusDate.Text;
                    cmd.Parameters.Add("@param7", SqlDbType.NVarChar, 50).Value = "Bus";


                    try
                    {
                        string str = "";
                        if (checkedListBoxBusSeats.CheckedItems.Count > 0)
                        {
                            for (int i = 0; i < checkedListBoxBusSeats.CheckedItems.Count; i++)
                            {

                                if (str == "")
                                {
                                    str = checkedListBoxBusSeats.CheckedItems[i].ToString();
                                }
                                else
                                {
                                    str += "," + checkedListBoxBusSeats.CheckedItems[i].ToString();

                                }
                            }

                            cmd.Parameters.Add("@param6", SqlDbType.NVarChar, 50).Value = str;
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message + ex.ToString());
                    }

                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();

                    con.Close();


                    LoginForm lff1 = new LoginForm();
                    this.Hide();
                    lff1.Show();
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show("Seats are taken, select another seat!");
            }
            
        }
    }
}
