﻿namespace WindowsFormsApplication2
{
    partial class TransportUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TransportUserControl));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.buttonPlane = new System.Windows.Forms.Button();
            this.buttonBus = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(109, 113);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(236, 169);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(413, 113);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(236, 169);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // buttonPlane
            // 
            this.buttonPlane.BackColor = System.Drawing.Color.White;
            this.buttonPlane.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPlane.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonPlane.Location = new System.Drawing.Point(109, 288);
            this.buttonPlane.Name = "buttonPlane";
            this.buttonPlane.Size = new System.Drawing.Size(236, 38);
            this.buttonPlane.TabIndex = 2;
            this.buttonPlane.Text = "PLANE";
            this.buttonPlane.UseVisualStyleBackColor = false;
            this.buttonPlane.Click += new System.EventHandler(this.buttonPlane_Click);
            // 
            // buttonBus
            // 
            this.buttonBus.BackColor = System.Drawing.Color.White;
            this.buttonBus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBus.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.buttonBus.Location = new System.Drawing.Point(413, 288);
            this.buttonBus.Name = "buttonBus";
            this.buttonBus.Size = new System.Drawing.Size(236, 38);
            this.buttonBus.TabIndex = 3;
            this.buttonBus.Text = "BUS";
            this.buttonBus.UseVisualStyleBackColor = false;
            this.buttonBus.Click += new System.EventHandler(this.buttonBus_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(103, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(258, 36);
            this.label6.TabIndex = 16;
            this.label6.Text = "Transportation";
            // 
            // TransportUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Controls.Add(this.label6);
            this.Controls.Add(this.buttonBus);
            this.Controls.Add(this.buttonPlane);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Name = "TransportUserControl";
            this.Size = new System.Drawing.Size(750, 390);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button buttonPlane;
        private System.Windows.Forms.Button buttonBus;
        private System.Windows.Forms.Label label6;
    }
}
