﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class HotellUserControl : UserControl
    {
        public HotellUserControl()
        {
            InitializeComponent();
        }

        private void buttonRetrieveShowHotels_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source = .;" + "database = MyDatabase;" + "integrated security = SSPI";
            SqlCommand command = new SqlCommand("select * from RegHotel", con);
            con.Open();
            SqlDataReader DR = command.ExecuteReader();
            BindingSource source = new BindingSource();
            source.DataSource = DR;
            dataGridViewShowwwHotels.DataSource = source;
            con.Close();
        }

        private void buttonDeleteShowHotel_Click(object sender, EventArgs e)
        {
            string constring = "data source =.;database = MyDatabase;integrated security = SSPI";
            string query = "DELETE FROM RegHotel WHERE hotelID='" + textBoxSearchHotell.Text + "'";
            SqlConnection conDatabase = new SqlConnection(constring);
            SqlCommand cmdDatabase = new SqlCommand(query, conDatabase);
            SqlDataReader myReader;

            try
            {
                conDatabase.Open();
                myReader = cmdDatabase.ExecuteReader();
                MessageBox.Show("Delete Successful");
                while (myReader.Read())
                {

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
