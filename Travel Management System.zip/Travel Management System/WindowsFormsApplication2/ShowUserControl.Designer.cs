﻿namespace WindowsFormsApplication2
{
    partial class ShowUserControl


    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxAddUserName = new System.Windows.Forms.TextBox();
            this.textBoxAddUserID = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerAddUserDOB = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButtonAddUserFemale = new System.Windows.Forms.RadioButton();
            this.radioButtonAddUserMale = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxAddUserNationality = new System.Windows.Forms.ComboBox();
            this.textBoxAddUserEmail = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxAddUserAddress = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBoxAddUserPhone = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxAddUserDesiredPassword = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.buttonClearAddUser = new System.Windows.Forms.Button();
            this.buttonSignupAddUser = new System.Windows.Forms.Button();
            this.buttonUpdateAddUser = new System.Windows.Forms.Button();
            this.buttonRetrieveAddUser = new System.Windows.Forms.Button();
            this.buttonDeleteAddUser = new System.Windows.Forms.Button();
            this.dataGridViewShowwUser = new System.Windows.Forms.DataGridView();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowwUser)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Snap ITC", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(165, 32);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(540, 51);
            this.label3.TabIndex = 15;
            this.label3.Text = "Customer Information";
            // 
            // textBoxAddUserName
            // 
            this.textBoxAddUserName.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAddUserName.Location = new System.Drawing.Point(136, 123);
            this.textBoxAddUserName.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddUserName.Name = "textBoxAddUserName";
            this.textBoxAddUserName.Size = new System.Drawing.Size(177, 22);
            this.textBoxAddUserName.TabIndex = 22;
            // 
            // textBoxAddUserID
            // 
            this.textBoxAddUserID.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAddUserID.Location = new System.Drawing.Point(136, 175);
            this.textBoxAddUserID.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddUserID.Name = "textBoxAddUserID";
            this.textBoxAddUserID.Size = new System.Drawing.Size(177, 22);
            this.textBoxAddUserID.TabIndex = 21;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(16, 175);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 17);
            this.label5.TabIndex = 20;
            this.label5.Text = "User ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(16, 123);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 17);
            this.label4.TabIndex = 19;
            this.label4.Text = "Name:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(16, 231);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 17);
            this.label1.TabIndex = 23;
            this.label1.Text = "Date of Birth:";
            // 
            // dateTimePickerAddUserDOB
            // 
            this.dateTimePickerAddUserDOB.CalendarMonthBackground = System.Drawing.SystemColors.ActiveBorder;
            this.dateTimePickerAddUserDOB.Location = new System.Drawing.Point(136, 231);
            this.dateTimePickerAddUserDOB.Margin = new System.Windows.Forms.Padding(4);
            this.dateTimePickerAddUserDOB.Name = "dateTimePickerAddUserDOB";
            this.dateTimePickerAddUserDOB.Size = new System.Drawing.Size(177, 22);
            this.dateTimePickerAddUserDOB.TabIndex = 24;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(8, 20);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 17);
            this.label2.TabIndex = 25;
            this.label2.Text = "Gender:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonAddUserFemale);
            this.groupBox1.Controls.Add(this.radioButtonAddUserMale);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(16, 281);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(297, 66);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            // 
            // radioButtonAddUserFemale
            // 
            this.radioButtonAddUserFemale.AutoSize = true;
            this.radioButtonAddUserFemale.ForeColor = System.Drawing.Color.White;
            this.radioButtonAddUserFemale.Location = new System.Drawing.Point(222, 20);
            this.radioButtonAddUserFemale.Margin = new System.Windows.Forms.Padding(4);
            this.radioButtonAddUserFemale.Name = "radioButtonAddUserFemale";
            this.radioButtonAddUserFemale.Size = new System.Drawing.Size(75, 21);
            this.radioButtonAddUserFemale.TabIndex = 27;
            this.radioButtonAddUserFemale.TabStop = true;
            this.radioButtonAddUserFemale.Text = "Female";
            this.radioButtonAddUserFemale.UseVisualStyleBackColor = true;
            // 
            // radioButtonAddUserMale
            // 
            this.radioButtonAddUserMale.AutoSize = true;
            this.radioButtonAddUserMale.ForeColor = System.Drawing.Color.White;
            this.radioButtonAddUserMale.Location = new System.Drawing.Point(120, 20);
            this.radioButtonAddUserMale.Margin = new System.Windows.Forms.Padding(4);
            this.radioButtonAddUserMale.Name = "radioButtonAddUserMale";
            this.radioButtonAddUserMale.Size = new System.Drawing.Size(59, 21);
            this.radioButtonAddUserMale.TabIndex = 26;
            this.radioButtonAddUserMale.TabStop = true;
            this.radioButtonAddUserMale.Text = "Male";
            this.radioButtonAddUserMale.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(16, 373);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(78, 17);
            this.label6.TabIndex = 27;
            this.label6.Text = "Nationality:";
            // 
            // comboBoxAddUserNationality
            // 
            this.comboBoxAddUserNationality.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxAddUserNationality.FormattingEnabled = true;
            this.comboBoxAddUserNationality.Location = new System.Drawing.Point(136, 370);
            this.comboBoxAddUserNationality.Margin = new System.Windows.Forms.Padding(4);
            this.comboBoxAddUserNationality.Name = "comboBoxAddUserNationality";
            this.comboBoxAddUserNationality.Size = new System.Drawing.Size(177, 24);
            this.comboBoxAddUserNationality.TabIndex = 28;
            // 
            // textBoxAddUserEmail
            // 
            this.textBoxAddUserEmail.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAddUserEmail.Location = new System.Drawing.Point(136, 427);
            this.textBoxAddUserEmail.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddUserEmail.Name = "textBoxAddUserEmail";
            this.textBoxAddUserEmail.Size = new System.Drawing.Size(177, 22);
            this.textBoxAddUserEmail.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(16, 427);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 17);
            this.label7.TabIndex = 29;
            this.label7.Text = "Email:";
            // 
            // textBoxAddUserAddress
            // 
            this.textBoxAddUserAddress.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAddUserAddress.Location = new System.Drawing.Point(136, 480);
            this.textBoxAddUserAddress.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddUserAddress.Multiline = true;
            this.textBoxAddUserAddress.Name = "textBoxAddUserAddress";
            this.textBoxAddUserAddress.Size = new System.Drawing.Size(177, 27);
            this.textBoxAddUserAddress.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(16, 480);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(64, 17);
            this.label8.TabIndex = 31;
            this.label8.Text = "Address:";
            // 
            // textBoxAddUserPhone
            // 
            this.textBoxAddUserPhone.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAddUserPhone.Location = new System.Drawing.Point(136, 530);
            this.textBoxAddUserPhone.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddUserPhone.Name = "textBoxAddUserPhone";
            this.textBoxAddUserPhone.Size = new System.Drawing.Size(177, 22);
            this.textBoxAddUserPhone.TabIndex = 34;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(16, 530);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 17);
            this.label9.TabIndex = 33;
            this.label9.Text = "Phone:";
            // 
            // textBoxAddUserDesiredPassword
            // 
            this.textBoxAddUserDesiredPassword.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.textBoxAddUserDesiredPassword.Location = new System.Drawing.Point(136, 579);
            this.textBoxAddUserDesiredPassword.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxAddUserDesiredPassword.Name = "textBoxAddUserDesiredPassword";
            this.textBoxAddUserDesiredPassword.Size = new System.Drawing.Size(177, 22);
            this.textBoxAddUserDesiredPassword.TabIndex = 36;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(13, 579);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(73, 17);
            this.label10.TabIndex = 35;
            this.label10.Text = "Password:";
            // 
            // buttonClearAddUser
            // 
            this.buttonClearAddUser.BackColor = System.Drawing.Color.Black;
            this.buttonClearAddUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonClearAddUser.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonClearAddUser.FlatAppearance.BorderSize = 2;
            this.buttonClearAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonClearAddUser.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonClearAddUser.Location = new System.Drawing.Point(321, 635);
            this.buttonClearAddUser.Margin = new System.Windows.Forms.Padding(4);
            this.buttonClearAddUser.Name = "buttonClearAddUser";
            this.buttonClearAddUser.Size = new System.Drawing.Size(75, 28);
            this.buttonClearAddUser.TabIndex = 37;
            this.buttonClearAddUser.Text = "Clear";
            this.buttonClearAddUser.UseVisualStyleBackColor = false;
            this.buttonClearAddUser.Click += new System.EventHandler(this.buttonClearAddUser_Click);
            // 
            // buttonSignupAddUser
            // 
            this.buttonSignupAddUser.BackColor = System.Drawing.Color.Black;
            this.buttonSignupAddUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonSignupAddUser.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonSignupAddUser.FlatAppearance.BorderSize = 2;
            this.buttonSignupAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Green;
            this.buttonSignupAddUser.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonSignupAddUser.Location = new System.Drawing.Point(321, 599);
            this.buttonSignupAddUser.Margin = new System.Windows.Forms.Padding(4);
            this.buttonSignupAddUser.Name = "buttonSignupAddUser";
            this.buttonSignupAddUser.Size = new System.Drawing.Size(75, 28);
            this.buttonSignupAddUser.TabIndex = 38;
            this.buttonSignupAddUser.Text = "Sign Up";
            this.buttonSignupAddUser.UseVisualStyleBackColor = false;
            this.buttonSignupAddUser.Click += new System.EventHandler(this.buttonSignupAddUser_Click);
            // 
            // buttonUpdateAddUser
            // 
            this.buttonUpdateAddUser.BackColor = System.Drawing.Color.Black;
            this.buttonUpdateAddUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonUpdateAddUser.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonUpdateAddUser.FlatAppearance.BorderSize = 2;
            this.buttonUpdateAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonUpdateAddUser.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonUpdateAddUser.Location = new System.Drawing.Point(505, 618);
            this.buttonUpdateAddUser.Margin = new System.Windows.Forms.Padding(4);
            this.buttonUpdateAddUser.Name = "buttonUpdateAddUser";
            this.buttonUpdateAddUser.Size = new System.Drawing.Size(75, 28);
            this.buttonUpdateAddUser.TabIndex = 41;
            this.buttonUpdateAddUser.Text = "Update";
            this.buttonUpdateAddUser.UseVisualStyleBackColor = false;
            this.buttonUpdateAddUser.Click += new System.EventHandler(this.buttonUpdateAddUser_Click);
            // 
            // buttonRetrieveAddUser
            // 
            this.buttonRetrieveAddUser.BackColor = System.Drawing.Color.Black;
            this.buttonRetrieveAddUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonRetrieveAddUser.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonRetrieveAddUser.FlatAppearance.BorderSize = 2;
            this.buttonRetrieveAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonRetrieveAddUser.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonRetrieveAddUser.Location = new System.Drawing.Point(413, 599);
            this.buttonRetrieveAddUser.Margin = new System.Windows.Forms.Padding(4);
            this.buttonRetrieveAddUser.Name = "buttonRetrieveAddUser";
            this.buttonRetrieveAddUser.Size = new System.Drawing.Size(75, 28);
            this.buttonRetrieveAddUser.TabIndex = 42;
            this.buttonRetrieveAddUser.Text = "Retrieve";
            this.buttonRetrieveAddUser.UseVisualStyleBackColor = false;
            this.buttonRetrieveAddUser.Click += new System.EventHandler(this.buttonRetrieveAddUser_Click);
            // 
            // buttonDeleteAddUser
            // 
            this.buttonDeleteAddUser.BackColor = System.Drawing.Color.Black;
            this.buttonDeleteAddUser.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonDeleteAddUser.FlatAppearance.BorderColor = System.Drawing.Color.Aquamarine;
            this.buttonDeleteAddUser.FlatAppearance.BorderSize = 2;
            this.buttonDeleteAddUser.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Red;
            this.buttonDeleteAddUser.ForeColor = System.Drawing.Color.Aquamarine;
            this.buttonDeleteAddUser.Location = new System.Drawing.Point(413, 635);
            this.buttonDeleteAddUser.Margin = new System.Windows.Forms.Padding(4);
            this.buttonDeleteAddUser.Name = "buttonDeleteAddUser";
            this.buttonDeleteAddUser.Size = new System.Drawing.Size(75, 28);
            this.buttonDeleteAddUser.TabIndex = 43;
            this.buttonDeleteAddUser.Text = "Delete";
            this.buttonDeleteAddUser.UseVisualStyleBackColor = false;
            this.buttonDeleteAddUser.Click += new System.EventHandler(this.buttonDeleteAddUser_Click);
            // 
            // dataGridViewShowwUser
            // 
            this.dataGridViewShowwUser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewShowwUser.Location = new System.Drawing.Point(345, 123);
            this.dataGridViewShowwUser.Name = "dataGridViewShowwUser";
            this.dataGridViewShowwUser.RowHeadersWidth = 51;
            this.dataGridViewShowwUser.RowTemplate.Height = 24;
            this.dataGridViewShowwUser.Size = new System.Drawing.Size(503, 473);
            this.dataGridViewShowwUser.TabIndex = 44;
            // 
            // ShowUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.Black;
            this.Controls.Add(this.dataGridViewShowwUser);
            this.Controls.Add(this.buttonDeleteAddUser);
            this.Controls.Add(this.buttonRetrieveAddUser);
            this.Controls.Add(this.buttonUpdateAddUser);
            this.Controls.Add(this.buttonSignupAddUser);
            this.Controls.Add(this.buttonClearAddUser);
            this.Controls.Add(this.textBoxAddUserDesiredPassword);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBoxAddUserPhone);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxAddUserAddress);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxAddUserEmail);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBoxAddUserNationality);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dateTimePickerAddUserDOB);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxAddUserName);
            this.Controls.Add(this.textBoxAddUserID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "ShowUserControl";
            this.Size = new System.Drawing.Size(809, 390);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewShowwUser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxAddUserName;
        private System.Windows.Forms.TextBox textBoxAddUserID;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePickerAddUserDOB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButtonAddUserMale;
        private System.Windows.Forms.RadioButton radioButtonAddUserFemale;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxAddUserNationality;
        private System.Windows.Forms.TextBox textBoxAddUserEmail;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxAddUserAddress;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBoxAddUserPhone;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxAddUserDesiredPassword;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button buttonClearAddUser;
        private System.Windows.Forms.Button buttonSignupAddUser;
        private System.Windows.Forms.Button buttonUpdateAddUser;
        private System.Windows.Forms.Button buttonRetrieveAddUser;
        private System.Windows.Forms.Button buttonDeleteAddUser;
        private System.Windows.Forms.DataGridView dataGridViewShowwUser;
    }
}