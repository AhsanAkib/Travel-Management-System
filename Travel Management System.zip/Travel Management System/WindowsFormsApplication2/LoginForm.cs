﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication2
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        private void buttonEnterLogin_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection();
            con.ConnectionString = "data source =.;database = MyDatabase;integrated security = SSPI";
           
            string sql = "Select * FROM RegTravel WHERE RegUserID='" + textBoxID.Text + "' and RegPassword='" + textBoxPasswordLogin.Text+"'";
            SqlDataAdapter sda = new SqlDataAdapter(sql, con);
            DataTable dtb1 = new DataTable();
            sda.Fill(dtb1);
            if(dtb1.Rows.Count==1)
            {
                Form1 f1 = new Form1();
                this.Hide();
                f1.Show();
            }
            else
            {
                MessageBox.Show("Wrong UserId & Password!");
            }
        }

        private void buttonRegister_Click(object sender, EventArgs e)
        {
            RegistryForm rf1 = new RegistryForm();
            this.Hide();
            rf1.Show();
        }

        private void buttonLoginAdmin_Click(object sender, EventArgs e)
        {
            AdminLoginForm alf1 = new AdminLoginForm();
            this.Hide();
            alf1.Show();
        }
    }
}
