﻿namespace WindowsFormsApplication2
{
    partial class HotelDetailsUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.checkedListBoxRoomHotel = new System.Windows.Forms.CheckedListBox();
            this.dateTimePickerCheckInHotel = new System.Windows.Forms.DateTimePicker();
            this.buttonDoneHotelDetails = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePickerCheckOutHotel = new System.Windows.Forms.DateTimePicker();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxTotalHotel = new System.Windows.Forms.TextBox();
            this.buttonBack = new System.Windows.Forms.Button();
            this.hotelUserControl1 = new WindowsFormsApplication2.HotelUserControl();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(77, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 36);
            this.label6.TabIndex = 37;
            this.label6.Text = "HOTEL:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(65, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 17);
            this.label4.TabIndex = 34;
            this.label4.Text = "Check-in: ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(426, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 17);
            this.label2.TabIndex = 32;
            this.label2.Text = "Available Rooms:";
            // 
            // checkedListBoxRoomHotel
            // 
            this.checkedListBoxRoomHotel.FormattingEnabled = true;
            this.checkedListBoxRoomHotel.Items.AddRange(new object[] {
            "A1",
            "B1",
            "C1",
            "D1",
            "E1",
            "F1",
            "G1",
            "H1",
            "I1",
            "J1"});
            this.checkedListBoxRoomHotel.Location = new System.Drawing.Point(565, 96);
            this.checkedListBoxRoomHotel.Name = "checkedListBoxRoomHotel";
            this.checkedListBoxRoomHotel.Size = new System.Drawing.Size(120, 174);
            this.checkedListBoxRoomHotel.TabIndex = 30;
            // 
            // dateTimePickerCheckInHotel
            // 
            this.dateTimePickerCheckInHotel.Location = new System.Drawing.Point(157, 96);
            this.dateTimePickerCheckInHotel.Name = "dateTimePickerCheckInHotel";
            this.dateTimePickerCheckInHotel.Size = new System.Drawing.Size(224, 22);
            this.dateTimePickerCheckInHotel.TabIndex = 29;
            // 
            // buttonDoneHotelDetails
            // 
            this.buttonDoneHotelDetails.BackColor = System.Drawing.Color.White;
            this.buttonDoneHotelDetails.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDoneHotelDetails.ForeColor = System.Drawing.Color.Black;
            this.buttonDoneHotelDetails.Location = new System.Drawing.Point(336, 299);
            this.buttonDoneHotelDetails.Name = "buttonDoneHotelDetails";
            this.buttonDoneHotelDetails.Size = new System.Drawing.Size(92, 28);
            this.buttonDoneHotelDetails.TabIndex = 26;
            this.buttonDoneHotelDetails.Text = "Done";
            this.buttonDoneHotelDetails.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(65, 152);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 17);
            this.label1.TabIndex = 39;
            this.label1.Text = "Check-out:";
            // 
            // dateTimePickerCheckOutHotel
            // 
            this.dateTimePickerCheckOutHotel.Location = new System.Drawing.Point(157, 152);
            this.dateTimePickerCheckOutHotel.Name = "dateTimePickerCheckOutHotel";
            this.dateTimePickerCheckOutHotel.Size = new System.Drawing.Size(224, 22);
            this.dateTimePickerCheckOutHotel.TabIndex = 38;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(65, 206);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 17);
            this.label3.TabIndex = 40;
            this.label3.Text = "Total:";
            // 
            // textBoxTotalHotel
            // 
            this.textBoxTotalHotel.Location = new System.Drawing.Point(157, 206);
            this.textBoxTotalHotel.Name = "textBoxTotalHotel";
            this.textBoxTotalHotel.Size = new System.Drawing.Size(224, 22);
            this.textBoxTotalHotel.TabIndex = 41;
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.White;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBack.ForeColor = System.Drawing.Color.Black;
            this.buttonBack.Location = new System.Drawing.Point(190, 299);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(92, 28);
            this.buttonBack.TabIndex = 42;
            this.buttonBack.Text = "Back";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // hotelUserControl1
            // 
            this.hotelUserControl1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.hotelUserControl1.Location = new System.Drawing.Point(3, 0);
            this.hotelUserControl1.Name = "hotelUserControl1";
            this.hotelUserControl1.Size = new System.Drawing.Size(755, 390);
            this.hotelUserControl1.TabIndex = 43;
            // 
            // HotelDetailsUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.textBoxTotalHotel);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateTimePickerCheckOutHotel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.checkedListBoxRoomHotel);
            this.Controls.Add(this.dateTimePickerCheckInHotel);
            this.Controls.Add(this.buttonDoneHotelDetails);
            this.Controls.Add(this.hotelUserControl1);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "HotelDetailsUserControl";
            this.Size = new System.Drawing.Size(755, 390);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckedListBox checkedListBoxRoomHotel;
        private System.Windows.Forms.DateTimePicker dateTimePickerCheckInHotel;
        private System.Windows.Forms.Button buttonDoneHotelDetails;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePickerCheckOutHotel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxTotalHotel;
        private System.Windows.Forms.Button buttonBack;
        private HotelUserControl hotelUserControl1;
    }
}
