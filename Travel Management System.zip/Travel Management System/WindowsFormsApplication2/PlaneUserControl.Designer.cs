﻿namespace WindowsFormsApplication2
{
    partial class PlaneUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedListBoxSeatPlane = new System.Windows.Forms.CheckedListBox();
            this.dateTimePickerPlane = new System.Windows.Forms.DateTimePicker();
            this.comboBoxToPlane = new System.Windows.Forms.ComboBox();
            this.comboBoxFromPlane = new System.Windows.Forms.ComboBox();
            this.buttonDonePlane = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBoxClassPlane = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkedListBoxSeatPlane
            // 
            this.checkedListBoxSeatPlane.FormattingEnabled = true;
            this.checkedListBoxSeatPlane.Items.AddRange(new object[] {
            "A1",
            "B1",
            "C1",
            "D1",
            "E1",
            "F1",
            "G1",
            "H1",
            "I1",
            "J1"});
            this.checkedListBoxSeatPlane.Location = new System.Drawing.Point(548, 57);
            this.checkedListBoxSeatPlane.Name = "checkedListBoxSeatPlane";
            this.checkedListBoxSeatPlane.Size = new System.Drawing.Size(120, 174);
            this.checkedListBoxSeatPlane.TabIndex = 18;
            // 
            // dateTimePickerPlane
            // 
            this.dateTimePickerPlane.Location = new System.Drawing.Point(127, 224);
            this.dateTimePickerPlane.Name = "dateTimePickerPlane";
            this.dateTimePickerPlane.Size = new System.Drawing.Size(224, 22);
            this.dateTimePickerPlane.TabIndex = 17;
            // 
            // comboBoxToPlane
            // 
            this.comboBoxToPlane.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxToPlane.FormattingEnabled = true;
            this.comboBoxToPlane.Location = new System.Drawing.Point(127, 116);
            this.comboBoxToPlane.Name = "comboBoxToPlane";
            this.comboBoxToPlane.Size = new System.Drawing.Size(224, 24);
            this.comboBoxToPlane.TabIndex = 16;
            // 
            // comboBoxFromPlane
            // 
            this.comboBoxFromPlane.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxFromPlane.FormattingEnabled = true;
            this.comboBoxFromPlane.Location = new System.Drawing.Point(127, 60);
            this.comboBoxFromPlane.Name = "comboBoxFromPlane";
            this.comboBoxFromPlane.Size = new System.Drawing.Size(224, 24);
            this.comboBoxFromPlane.TabIndex = 15;
            // 
            // buttonDonePlane
            // 
            this.buttonDonePlane.BackColor = System.Drawing.Color.White;
            this.buttonDonePlane.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDonePlane.ForeColor = System.Drawing.Color.Black;
            this.buttonDonePlane.Location = new System.Drawing.Point(335, 333);
            this.buttonDonePlane.Name = "buttonDonePlane";
            this.buttonDonePlane.Size = new System.Drawing.Size(92, 28);
            this.buttonDonePlane.TabIndex = 14;
            this.buttonDonePlane.Text = "Done";
            this.buttonDonePlane.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(61, 229);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(47, 17);
            this.label4.TabIndex = 22;
            this.label4.Text = "Date:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(61, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 17);
            this.label3.TabIndex = 21;
            this.label3.Text = "To:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(420, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(125, 17);
            this.label2.TabIndex = 20;
            this.label2.Text = "Available Seats:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(61, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 19;
            this.label1.Text = "From:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(61, 172);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 17);
            this.label5.TabIndex = 24;
            this.label5.Text = "Class:";
            // 
            // comboBoxClassPlane
            // 
            this.comboBoxClassPlane.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.comboBoxClassPlane.FormattingEnabled = true;
            this.comboBoxClassPlane.Location = new System.Drawing.Point(127, 172);
            this.comboBoxClassPlane.Name = "comboBoxClassPlane";
            this.comboBoxClassPlane.Size = new System.Drawing.Size(224, 24);
            this.comboBoxClassPlane.TabIndex = 23;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Snap ITC", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(64, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 36);
            this.label6.TabIndex = 25;
            this.label6.Text = "PLANE:";
            // 
            // PlaneUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBoxClassPlane);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkedListBoxSeatPlane);
            this.Controls.Add(this.dateTimePickerPlane);
            this.Controls.Add(this.comboBoxToPlane);
            this.Controls.Add(this.comboBoxFromPlane);
            this.Controls.Add(this.buttonDonePlane);
            this.ForeColor = System.Drawing.Color.White;
            this.Name = "PlaneUserControl";
            this.Size = new System.Drawing.Size(755, 390);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedListBoxSeatPlane;
        private System.Windows.Forms.DateTimePicker dateTimePickerPlane;
        private System.Windows.Forms.ComboBox comboBoxToPlane;
        private System.Windows.Forms.ComboBox comboBoxFromPlane;
        private System.Windows.Forms.Button buttonDonePlane;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxClassPlane;
        private System.Windows.Forms.Label label6;
    }
}
